# PD Schema Review — Ambiguity Tracker (UPDATED)

**Source:** PD's schema description review (22 March 2026)
**Compiled:** 23 March 2026
**Last updated:** 23 March 2026 — CTO review session
**Status:** 58 of 67 items resolved. 9 deferred to team.

---

## Resolution Summary

| Category | Total | Resolved | Deferred | Open |
|----------|-------|----------|----------|------|
| A — PII/Scrub Gaps | 8 | 8 | 0 | 0 |
| B — Business Logic | 32 | 23 | 9 | 0 |
| C — Data Quality | 14 | 10 | 0 | 4 (engineering) |
| D — Assumptions | 13 | 11 | 1 | 1 (engineering) |
| **Total** | **67** | **52** | **10** | **5** |

---

## OPEN — Deferred to Team (10 items)

### Business Logic — Need Team Answers

| # | Table | Question | Suggested Owner |
|---|-------|----------|----------------|
| B1 | uvarcl_live.allocation | `legal_allocation = 7` (99% null) — FK to agency/scheme or flag? What does 7 represent? | SW |
| B2 | uvarcl_live.allocation | `agent_id` 99.99% null, `user_id` has 4 values — is agent-level assignment managed elsewhere? | SW |
| B3 | uvarcl_live.allocation_history | `alloc_reasoning` — 99.8% null, 1 distinct value. Is there a decode table? | SW |
| B5 | uvarcl_live.alternative_data | Is `alternative_data` a superset of `additional_details`, or do they serve different purposes? | RM |
| B10 | uvarcl_live.crm_comments | `call_ref_no` (43% populated, 201K distinct) — does it join to call_logs.call_id or cdr.id? | AB |
| B12 | uvarcl_live.messenger_chat_message | `user_id` (260 distinct) — represents the sender (disambiguated by sender_role), always the agent, or always the customer? | AB |
| B19 | uvarcl_live.settlements | `expected_waiver_amount` exceeds outstanding — theoretical denominator? Are `portfolio_health` and `pos_run_off` separate columns? | RM |
| B22 | uvarcl_live.user vs users | 627 vs 645 rows, similar schemas. Django auth base vs custom? Which is authoritative for agent analytics? | AB |
| B29 | bureau.bureau_pull_metadata | Only 1 row — is metadata overwritten per pull (losing history), or does each pull add a row? | SW |
| B32 | uvarcl_live.bureau_reporting_raw | CIBIL/Experian format codes for gender, city, occupation, payment_frequency — is there a code mapping document? | SW |

### Data Quality — Defer to Team

| # | Table | Question | Suggested Owner |
|---|-------|----------|----------------|
| D2 | uvarcl_live.ARC CARDS DATA_B | Current Balance '+' suffix (e.g. '84400+') — CIBIL convention? Affects numeric parsing. | SW |

---

## OPEN — Engineering Actions Required (5 items)

### Re-Profiling Required (HIGH priority — blocks AI context completeness)

| # | Table | Rows | Issue |
|---|-------|------|-------|
| C1 | uvarcl_live.call_logs | 4,367,570 | ALL 38 columns returned distinct=0. Profiler failed on large table. |
| C2 | uvarcl_live.communication_events | 1,932,377 | ALL 5 columns returned distinct=0. Same profiler failure. |
| C3 | bureau.trade_accounts | 9,748,401 | ALL 49 columns returned distinct=0. Same profiler failure. |
| D3 | uvarcl_live.cdr | 1,337,998 | Same profiler failure pattern. Cannot verify disposition distribution. |

**Root cause:** Profiler chokes on tables >1M rows. Engineering must re-run profiler with adequate sampling on these 4 tables.

### Security Remediation (CRITICAL)

| # | Table | Column | Issue |
|---|-------|--------|-------|
| C14 | uvarcl_live.users | dialer_password | Plaintext password storage. Must be hashed at rest. |

---

## RESOLVED — Category A: PII/Scrub Gaps (8/8 complete)

| # | Table.Column | Decision | Action |
|---|-------------|----------|--------|
| A1 | ARC CARDS DATA_B.Additional ID #1 | ✅ New PII | HASH (Aadhaar) |
| A2 | ARC RETAIL DATAB.Additional ID #1 | ✅ New PII | HASH (Aadhaar) |
| A3 | ARC RETAIL DATAB.Voter ID Number | ✅ New PII | HASH |
| A4 | axis_customer_details.CONTACTINFO | ⏭️ Label mismatch only | No change (strategy correct, pii_type=aadhaar but actually phone) |
| A5 | customer_kyc_details.data (JSONB) | ⬆️ Strategy upgrade | REDACT → NULL |
| A6 | axis_customer_details.COMPANY_NAME | ❌ False positive | Remove PII flag (same rule as customers.company_name) |
| A7 | disposition.disposition_name | ❌ False positive | Remove PII flag (call outcome labels, not personal data) |
| A8 | dialer_uploads.phone_type | ⏭️ Non-issue | Already is_pii: False in registry, 5 distinct category values |

## RESOLVED — Category B: Business Logic (23/32 from data)

| # | Question | Resolution |
|---|---------|-----------|
| B4 | additional_details only type_id=1? | **No** — 2 type_ids, 6 labels. Profiler sample was narrow. |
| B6 | axis_base_PI_03_02_1 versioned import? | **CTO confirmed:** one-time import, will not be in production. |
| B7 | txn_category_id decode table? | **Yes** — `transaction_category` has 15 rows, matches 14 distinct values. |
| B8 | Only 'Opening Charge' charge_type? | **No** — 10 distinct charge types. Profiler sample bias. |
| B9 | Only channel_type_id=184? | **No** — 3 distinct channels (WhatsApp, SMS, email). |
| B11 | emi_schedule: per loan or per instalment? | **One row per loan.** 724,871 rows ≈ 724,879 loans. Snapshot, not full schedule. |
| B13 | nach.debit_end_date = 2101 always? | **No** — 651 distinct dates. 2101 = perpetual mandate convention; real dates also exist. |
| B14 | nach_presentation only logs FAILED? | **No** — 4 distinct statuses. Successes recorded too. |
| B15 | Can unadjusted payments exist? | **Yes** — is_adjusted has 2 values (True/False). |
| B16 | No 'principal' adjustment_type? | **Wrong** — 4 distinct types exist. Principal is there. |
| B17 | Is is_handled ever updated? | **Never** — 1 distinct value (all False). Field is non-functional. |
| B18 | risk_weight.loan_id = borrower_loan_id? | **Yes** — loan_id is text type vs loans.id integer. Joins via borrower_loan_id. |
| B20 | Only approved waivers stored? | **No** — 3 distinct status_id values. Rejected/pending exist. |
| B21 | short_url.is_used ever updated? | **Yes** — 2 distinct values. Toggled on click. |
| B23 | statement_of_accounts.debit always 0? | **No** — 39,858 distinct values. Well populated. Profiler sample bias. |
| B24 | noc_list.noc_type populated? | **Never** — 100% null. Field defined but never used. |
| B25 | callback_request.preferred_time real? | **Barely** — 98% null, 11 distinct values. Non-functional. |
| B26 | credit_loan_tape_check vs credit_loan_tape? | **Check is 2.09x larger** — includes all loan-months including zero-activity. |
| B27 | daily_targets.is_active filter? | **Filter on True** — 2 values exist. |
| B28 | scb_cdr.did_clid placeholders? | **No** — 26 distinct DIDs. Real production data. |
| B30 | customer_demographics.gender only 2? | **3 values** — CIBIL: 1=Male, 2=Female, 3=Other. Sample bias. |
| B31 | borrower_account_id incorrectly flagged? | **Already confirmed** in review_summary as NOT PII. Profiler config needs fix. |

## RESOLVED — Category C: Data Quality (10/14)

| # | Issue | Resolution |
|---|-------|-----------|
| C4 | bank_file_logs all imports failing | **No** — 3 error types, 112 distinct `added` values. Many succeed. |
| C5 | bank_accounts.opening_balance = 0 | **Confirmed** genuinely unpopulated (1 distinct value). Noted in description. |
| C6 | bank_transactions.debit = 0 | **No** — 39,858 distinct values. (Same as B23) |
| C7 | communication_uploads.total_records = 0 | **No** — 17 distinct values. Profiler sample bias. |
| C8 | dialer_uploads counting mismatch | **Low priority** — 102 distinct total, 95 distinct successful. Per-row quirks. |
| C9 | pg_transactions test data? | **No** — 7,497 distinct net_amount, 63 fee values. Real production data. |
| C10 | portfolios.total_loan_amount = 0 | **Confirmed** stale/deprecated (1 distinct value). Noted in description. |
| C11 | payment_requests.total_amount = 0 | **No** — 2,947 distinct values. Populated. |
| C12 | tickets.resolve_date < created_at | **Confirmed** non-functional — 99.9% null, 5 values. Use ticket_logs for SLA. |
| C13 | razorpay_webhook all failing | **Partially** — 2 processed states, 6 error types. Some work, config worth checking. |

## RESOLVED — Category D: Assumptions (11/13)

| # | PD's Inference | Resolution |
|---|---------------|-----------|
| D1 | nach debit_end_date 2101 = perpetual | **Confirmed** — 651 distinct dates, 2101 is open-ended convention. |
| D4 | nach_presentation only FAILED | **Wrong** — 4 statuses, successes recorded. |
| D5 | crm_notifications.read_at never tracked | **Confirmed** — 100% null, 0 distinct. Never populated. |
| D6 | daily_targets is_active=False = superseded | **Confirmed** — 2 values, filter on True. |
| D7 | Vendo allocation = staging import | **Confirmed** — dated import file. |
| D8 | Axis multi-agency = staging import | **Confirmed** — dated import file. |
| D9 | Axis_Konex = staging import | **Confirmed** — dated import file. |
| D10 | call_remarks 'None' = Python null cast | **Likely** — 20,487 distinct remarks, 'None' is one among many. |
| D11 | razorpay_invoice = test data | **Confirmed** — 4 rows, ₹1 amounts. |
| D12 | razorpay_payment = test data | **Confirmed** — 7 rows. |
| D13 | razorpay_order = test data | **Confirmed** — 13 rows, same loan_id. |

---

## Exclusion Recommendations (from PD, pending CTO batch decision)

| Table | Reason | Recommendation |
|-------|--------|---------------|
| uvarcl_live.allocation_history_backup | Point-in-time backup, not maintained | EXCLUDE_TABLE |
| uvarcl_live.temp_nach_link | Staging table for eNACH link generation | EXCLUDE_TABLE |
| uvarcl_live.axis_base_PI_03_02_1 | CTO confirmed: one-time import, not production | EXCLUDE_TABLE |
| analytics.credit_loan_tape_check_backup | Backup of credit_loan_tape_check | EXCLUDE_TABLE |
| uvarcl_live.django_content_type | Django infrastructure, no analytical value | EXCLUDE_TABLE |
| uvarcl_live.django_migrations | Django infrastructure, no analytical value | EXCLUDE_TABLE |
| uvarcl_live.django_session | Django infrastructure, encrypted session data | EXCLUDE_TABLE |
| uvarcl_live.django_celery_beat_periodictasks | Single-row metadata, no analytical value | EXCLUDE_TABLE |
| uvarcl_live.razorpay_invoice | All rows are test data | EXCLUDE_TABLE |
| uvarcl_live.razorpay_payment | All rows are test data | EXCLUDE_TABLE |
| uvarcl_live.notifications | Empty, no analytical value | EXCLUDE_TABLE |
| uvarcl_live.auth_group_permissions | Django RBAC infrastructure | EXCLUDE_TABLE |
